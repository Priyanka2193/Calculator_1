﻿using System;

namespace Calculator
{
    class Program
    {
        static int  i;
        static void Main(string[] args)
        {
            Console.WriteLine("Caculator");
            Display();
            while (i != 0)
            {

                if (i > 0 && i < 6)
                {
                    Console.WriteLine("Enter the inputs");
                    Console.WriteLine("Enter  a");
                    double a = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter  b");
                    double b = Convert.ToDouble(Console.ReadLine());
                    Calculate(a, b, i);
                    Display();
                    //Console.WriteLine("\n1.Add\n2.Sub\n3.Multiply\n4.Divide\n5.Remiander\n0.exit");
                    //i = Convert.ToInt32(Console.ReadLine());
                }
                else
                {
                    Console.WriteLine("Please select the proper input from below:");
                    Display();
                    //Console.WriteLine("\n1.Add\n2.Sub\n3.Multiply\n4.Divide\n5.Remiander\n0.exit");
                    //i = Convert.ToInt32(Console.ReadLine());

                }

            }


        }

        private static void Display()
        {
            Console.WriteLine("\n1.Add\n2.Sub\n3.Multiply\n4.Divide\n5.Remiander\n0.exit");
            i = Convert.ToInt32(Console.ReadLine());
        }

        public static void Calculate(double a, double b, int selection)
        {
            try
            {
                switch (selection)
                {
                    case 1:
                        Console.WriteLine("Sum: " + (a + b));
                        break;
                    case 2:
                        Console.WriteLine("Difference: " + (a - b));
                        break;
                    case 3:
                        Console.WriteLine("Multiply: " + (a * b));
                        break;
                    case 4:
                        try
                        {
                            decimal s = Convert.ToDecimal(a);
                            decimal t = Convert.ToDecimal(b);
                            Console.WriteLine("Divide: " + Math.Round((s / t),2));
                        }
                        catch (DivideByZeroException)
                        {
                            Console.WriteLine("Division of {0} by zero." + a);
                        }

                        break;
                    case 5:
                        Console.WriteLine("Remainder:" + Math.Round((a % b), 2));
                        break;
                    default:
                        Console.WriteLine("Please select proper selection!");
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

       

    }
}
